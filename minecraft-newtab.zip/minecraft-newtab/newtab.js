 
function newQuote() {  const q = quotes[Math.floor(Math.random() * quotes.length)];  document.getElementById('quote').textContent = `"${q}"`;} 
function updateClock() {  const now = new Date();  document.getElementById('clock').textContent = now.toLocaleTimeString();} 
setInterval(updateClock, 1000); 
updateClock(); 
newQuote(); 
 
const music = document.getElementById('music'); 
document.getElementById('toggleMusic').addEventListener('click', () = if (music.paused) {    music.play();    document.getElementById('toggleMusic').textContent = '⏸️ Pause Music';  } else {    music.pause();    document.getElementById('toggleMusic').textContent = '🎵 Play Music';  }}); 
