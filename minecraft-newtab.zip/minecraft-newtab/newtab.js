const quotes = [
  "The best view comes after the hardest climb.",
  "Creepers were a bug that exploded into popularity.",
  "Never dig straight down!",
  "Survive the night, thrive by day.",
  "Punching trees since 2009."
];

function newQuote() {
  const q = quotes[Math.floor(Math.random() * quotes.length)];
  document.getElementById('quote').textContent = `"${q}"`;
}

function updateClock() {
  const now = new Date();
  document.getElementById('clock').textContent = now.toLocaleTimeString();
}

// Start clock and display initial quote
setInterval(updateClock, 1000);
updateClock();
newQuote();

// Music toggle button
const music = document.getElementById('music');
document.getElementById('toggleMusic').addEventListener('click', () => {
  if (music.paused) {
    music.play();
    document.getElementById('toggleMusic').textContent = '⏸️ Pause Music';
  } else {
    music.pause();
    document.getElementById('toggleMusic').textContent = '🎵 Play Music';
  }
});
